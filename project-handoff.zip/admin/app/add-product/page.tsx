// product-admin\app\add-product\page.tsx

'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import type { WebsiteProduct } from '@/types/database';
import { compressImage } from '@/lib/image-utils';

export default function AddProductPage() {
  const router = useRouter();

  const [websiteProducts, setWebsiteProducts] = useState<WebsiteProduct[]>([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [manualMode, setManualMode] = useState(false);
  const [manualName, setManualName] = useState('');

  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [images, setImages] = useState<File[]>([]);
  
  // Variant fields
  const [sku, setSku] = useState('');
  const [price, setPrice] = useState('');
  const [stockQty, setStockQty] = useState('');
  
  const [loading, setLoading] = useState(false);

  // Load product names from website_products
  useEffect(() => {
    async function loadProducts() {
      const { data, error } = await supabase
        .from('website_products')
        .select('id, name')
        .order('name');

      if (!error && data) setWebsiteProducts(data);
    }

    loadProducts();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    const uploadedUrls: string[] = [];

    // Determine product name first (needed for filenames)
    const productName = manualMode
      ? manualName
      : websiteProducts.find((p) => p.id === selectedProductId)?.name;

    // Create slug from product name for filenames
    const slug = productName?.toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'product';

    // Upload images
    for (let i = 0; i < images.length; i++) {
      const file = images[i];
      const fileExt = file.name.split('.').pop();
      const timestamp = Date.now();
      const fileName = `${slug}-${i + 1}-${timestamp}.${fileExt}`;
      const filePath = `products/${fileName}`;
      const { error } = await supabase.storage
        .from('product-images')
        .upload(filePath, file);

      if (error) {
        console.error('Image upload error:', error);
        alert(`Failed to upload image: ${error.message || 'Unknown error'}`);
        setLoading(false);
        return;
      }

      const url = supabase.storage
        .from('product-images')
        .getPublicUrl(filePath).data.publicUrl;

      uploadedUrls.push(url);
    }

    // Insert product via API route
    const response = await fetch('/api/create-product', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        product: {
          name: productName,
          category,
          description,
          images: uploadedUrls,
        },
        variants: (sku || price || stockQty) ? [{
          sku: sku || null,
          price: price ? parseFloat(price) : null,
          stock_qty: stockQty ? parseInt(stockQty) : null,
          option_values: {},
        }] : [],
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('Product creation error:', error);
      alert(`Failed to save product: ${error.error || 'Unknown error'}`);
      setLoading(false);
      return;
    }

    alert('Product saved successfully!');
    setLoading(false);
    
    // Redirect to preview page
    window.location.href = 'https://frontend-six-kappa-30.vercel.app/preview';
  }

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-xl font-bold mb-4">Add Product</h1>

      <form onSubmit={handleSubmit} className="space-y-4">

        {/* Toggle for manual entry */}
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={manualMode}
            onChange={(e) => setManualMode(e.target.checked)}
          />
          This product is not on the website list
        </label>

        {/* Product name dropdown OR manual input */}
        {!manualMode && (
          <select
            className="w-full p-2 border rounded"
            value={selectedProductId}
            onChange={(e) => setSelectedProductId(e.target.value)}
            required={!manualMode}
          >
            <option value="">Select product name</option>
            {websiteProducts.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        )}

        {manualMode && (
          <input
            type="text"
            placeholder="Enter product name"
            className="w-full p-2 border rounded"
            value={manualName}
            onChange={(e) => setManualName(e.target.value)}
            required={manualMode}
          />
        )}

        {/* Category dropdown */}
        <select
          className="w-full p-2 border rounded"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          required
        >
          <option value="">Select category</option>
          <option value="hive">Hive</option>
          <option value="frames">Frames</option>
          <option value="foundation">Foundation</option>
          <option value="equipment">Equipment</option>
          <option value="clothing">Clothing</option>
          <option value="other">Other</option>
        </select>

        {/* Description */}
        <textarea
          placeholder="Description"
          className="w-full p-2 border rounded"
          rows={4}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        {/* Image upload */}
        <div>
          <label className="block font-medium mb-1">Upload Images</label>
          <label className="block w-full p-3 border-2 border-dashed rounded cursor-pointer bg-gray-50 hover:bg-gray-100 text-center transition-colors">
            <span className="text-gray-600">📷 Click to choose images</span>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={async (e) => {
                const files = Array.from(e.target.files || []);
                const compressed = await Promise.all(files.map(compressImage));
                setImages(compressed);
              }}
              className="hidden"
            />
          </label>
          {images.length > 0 && (
            <p className="text-sm text-gray-600 mt-2">{images.length} image(s) selected</p>
          )}
        </div>

        {/* Variant Section */}
        <div className="border-t pt-4 mt-4">
          <h2 className="text-lg font-semibold mb-3">Pricing & Stock (Optional)</h2>
          <div className="space-y-3">
            <input
              type="text"
              placeholder="SKU (e.g., BB-1412)"
              className="w-full p-2 border rounded"
              value={sku}
              onChange={(e) => setSku(e.target.value)}
            />
            <input
              type="number"
              step="0.01"
              placeholder="Price (£)"
              className="w-full p-2 border rounded"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
            <input
              type="number"
              placeholder="Stock Quantity"
              className="w-full p-2 border rounded"
              value={stockQty}
              onChange={(e) => setStockQty(e.target.value)}
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 text-white p-2 rounded"
        >
          {loading ? 'Saving…' : 'Save Product'}
        </button>
      </form>
    </div>
  );
}
